<?php
var_dump(__DIR__); //このディレクトリまでのパス(不要)

 include 'inc/header.php';  // 相対パスでも読み込めます
   
 include 'inc/input-form.php'  ;

 include 'inc/footer.php'; 

