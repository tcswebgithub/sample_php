<?php
$password = 'aBcDeF2468@=';
echo password_hash( $password, PASSWORD_DEFAULT );