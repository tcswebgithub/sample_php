-- Leson6/01/create-table-users.sql
-- usersテーブルを新規作成します 
create table users (
  id int NOT NULL auto_increment ,
  username varchar(255) ,
  `password` varchar(255),
  primary key(id)
);