<?php
$token = bin2hex(random_bytes(20));
echo $token;